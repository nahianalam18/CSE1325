#include "Vehicle.h"
#include <map>

Vehicle::Vehicle(int year,std::string make,std::string model,Body_style body_style){
  _year = year;
  _make = make;
  _model = model;
  _body_style = body_style;
}

std::string Vehicle::to_string(Body_style y){
    

        std::map<Body_style, std::string> to_str =
        {
        {Body_style::SEDAN, "SEDAN"},
        {Body_style::HATCHBACK, "HATCHBACK"},
        {Body_style::MINIVAN, "MINIVAN"},
        {Body_style::TRUCK, "TRUCK"},
        {Body_style::SUV, "SUV"},
        {Body_style::CROSSOVER, "CROSSOVER"}
        };
         
 

    return (to_str.at(y));
}

  std::string Vehicle::get_make()
  {
    return _make;
  }
  std::string Vehicle::get_model(){
    return _model;
  }
  Body_style Vehicle::get_body_style(){
    return _body_style;
  }
  int Vehicle::get_year(){
    return _year;
  }