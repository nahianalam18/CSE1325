#include <iostream>
#include "Vehicle.h"
#include "Gas_vehicle.h"
#include "Electric_vehicle.h"
#include <vector>

std::string calprice(double fuel_consumed, double price){
   return (std::to_string((fuel_consumed*price)));
}


int main() {
  
  std::vector<Electric_vehicle> evs = {
        Electric_vehicle{2014, "Telsa", "Model S 85", Body_style::SEDAN,3.12,85},
        Electric_vehicle{2014, "Telsa", "Model 3 LR", Body_style::SEDAN,4.13,75},
        Electric_vehicle{2018, "GM", "Bolt", Body_style::HATCHBACK,3.58,60},
        Electric_vehicle{2018, "Nissan", "LEAF SL", Body_style::HATCHBACK,3.88,40},
    };

  std::vector<Gas_vehicle> ice = {
        Gas_vehicle{2017, "Toyota", "RAV4", Body_style::CROSSOVER,26,15.9},
        Gas_vehicle{2018, "Ford", "F-150", Body_style::TRUCK,21,36},
        Gas_vehicle{2018, "Nissan", "Rogue", Body_style::HATCHBACK,29,14.5},
        Gas_vehicle{2018, "Chrysler", "Pacifica", Body_style::MINIVAN,22,19},
    };
    
  std::vector<double> oprice ={2, 2.25, 2.50, 3 , 4 };
  std::vector<double> eprice = {0.05,0.08,0.11,0.13,0.15};

  std::cout<<("\n\n\nFor electric vehicles:\n");

  for(int i=0;i<evs.size();i++)
  {
     std::cout<<("\n\n"+std::to_string(evs[i].get_year())+" "+evs[i].get_make()+" "+evs[i].get_model()+" "+evs[i].to_string(evs[i].get_body_style())+" costs per 100 miles:");
    for(int j=0;j<eprice.size();j++)
    {
      std::cout << ("\nAt $" + std::to_string(eprice[j]) + " per kwh -> $"+ calprice(evs[i].kwh_consumed(100),eprice[j]));
    }
  }

  std::cout<<("\n\n\nFor gas vehicles:\n");

  for(int i=0;i<ice.size();i++)
  {
     std::cout<<("\n\n"+std::to_string(ice[i].get_year())+" "+ice[i].get_make()+" "+ice[i].get_model()+" "+evs[i].to_string(evs[i].get_body_style())+" costs per 100 miles:");
    for(int j=0;j<oprice.size();j++)
    {
      std::cout << ("\nAt $" + std::to_string(oprice[j]) + " per gallon -> $"+ calprice(ice[i].gallons_consumed(100),oprice[j]));
    }
  }



  //Electric_vehicle jo(2,"HI","BYE",Body_style::MINIVAN,23.4,51.4);
  //std::cout <<("\nHello "+ jo.to_string(2,jo.get_body_style()));

}