#ifndef VEHICLE_H
#define VEHICLE_H


#include <iostream>

enum class Body_style {SEDAN,HATCHBACK,MINIVAN,TRUCK,SUV,CROSSOVER};

class Vehicle

{
  public:
  Vehicle(int year,std::string make,std::string model,Body_style body_style);
 
  std::string to_string(Body_style y);
  std::string get_make();
  std::string get_model();
  Body_style get_body_style();
  int get_year();


  private:
    std::string _make;
    Body_style _body_style;
    std::string _model;
    int _year;
   
  
};
#endif