
#include "Vehicle.h"
#include "Gas_vehicle.h"

  
Gas_vehicle::Gas_vehicle(int year,std::string make,std::string model,Body_style body_style, double miles_per_gallon, double max_gallons):Vehicle(year,make,model,body_style){
  _miles_per_gallon = miles_per_gallon;
  _max_gallons = max_gallons;
}

double Gas_vehicle::gallons_consumed(double miles){
  double output = miles/_miles_per_gallon;
  if(output>_max_gallons) throw std::runtime_error{"ERROR!"};
  return output;
}


